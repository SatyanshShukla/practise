package com.example.practise.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.practise.dao.CourseDao;
import com.example.practise.entities.Courses;
import com.example.practise.services.CourseService;
@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDao courseDao;
//	List<Courses> list;
//	public CourseServiceImpl() {
//		list=new ArrayList<>();
//		list.add(new Courses(1,"Java Course"));
//		list.add(new Courses(2,"Python Course"));
//	}
	@Override
	public List<Courses> getCourses() {
		// TODO Auto-generated method stub
		return courseDao.findAll();
	}
	@Override
	public Courses getCourse(long courseId) {
		// TODO Auto-generated method stub
//		Courses c = null;
//		for(Courses courses:list)
//		{
//			if(courses.getId()==courseId)
//			{
//				c=courses;
//			break;
//			}
//		}
		return courseDao.getOne(courseId);
	}
	@Override
	public Courses addCourse(Courses course) {
//		list.add(course);
		courseDao.save(course);
		return course;
	}
	
}
