package com.example.practise.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.practise.entities.Courses;

public interface CourseDao extends JpaRepository<Courses, Long>{

}
