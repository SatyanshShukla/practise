package com.example.practise;

import static org.assertj.core.api.Assertions.assertThat;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import com.example.practise.controller.MyController;
import com.example.practise.entities.Courses;
import com.example.practise.services.CourseService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@WebMvcTest(value=MyController.class)
class PractiseApplicationTests {
		final ObjectMapper objectMapper = new ObjectMapper();
		@Autowired
	    private MockMvc mvc;
	    @MockBean
	    private CourseService courseService;
	    @Test
	    public void practiseTest() throws Exception {
	    	
			List<Courses> list = Arrays.asList(new Courses(1,"Java Course"));
			//Mocking courseService
	    	Mockito.when(courseService.getCourses()).thenReturn(list);
	    	assertThat(objectMapper.readValue(mvc.perform(MockMvcRequestBuilders.get("/courses")).andReturn().getResponse().getContentAsString(), new TypeReference<List<Courses>>(){}).size()).isEqualTo(list.size());
			mvc.perform(MockMvcRequestBuilders.get("/home"))
				      .andExpect(MockMvcResultMatchers.status().isOk())
				      .andExpect(MockMvcResultMatchers.content().string("I am Satyansh! Welcome."));
		}
	}
